==============
Questionnaires
==============

Questionnaires is a simple Django app to conduct Web-based tests.
Each quiz can have multiple pages with questions and multiple choices
that the user can select.

Quick start
-----------

1. Install the app using the command 'pip install questionnaires'

2. Add "questionnaires" to your INSTALLED_APPS setting like this:

INSTALLED_APPS = (
          ...
          'questionnaires',
)

3. Add the following line to settings.py to save every request in session.

SESSION_SAVE_EVERY_REQUEST = True

4. Include the questionnaries URLconf in your project urls.py like this:

	url(r'^questionnaires/', include('questionnares.urls')),

5. Run 'python manage.py migrate' to create the questionnaires models.

6. Start the development server and visit http://127.0.0.1:8000/admin/
   to create a questionnaire (you'll need the Admin app enabled).

7. Visit http://127.0.0.1:8000/questionnaires/ to participate in the
   questionnaire.